# Senbara Common

Shared components for the Senbara reference applications.

## Overview

🚧 This project is a work-in-progress! Instructions will be added as soon as it is usable. 🚧

## License

Senbara Common (c) 2025 Felicitas Pojtinger and contributors

SPDX-License-Identifier: AGPL-3.0
