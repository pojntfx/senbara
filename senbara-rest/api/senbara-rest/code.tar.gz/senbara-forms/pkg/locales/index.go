package locales

import "embed"

//go:embed *
var FS embed.FS
