# Senbara REST

REST API for a simple personal ERP web application built with the Go standard library, OpenID Connect authentication and PostgreSQL data storage. Designed as a reference for modern REST API development with Go.

## Overview

🚧 This project is a work-in-progress! Instructions will be added as soon as it is usable. 🚧

## License

Senbara REST (c) 2025 Felicitas Pojtinger and contributors

SPDX-License-Identifier: AGPL-3.0
