package api

//go:generate oapi-codegen --config=../openapi/openapi-codegen.yaml ../openapi/openapi.yaml
