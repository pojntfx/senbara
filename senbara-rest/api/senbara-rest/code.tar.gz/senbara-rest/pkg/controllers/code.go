package controllers

import (
	"context"

	"github.com/pojntfx/senbara/senbara-rest/pkg/api"
)

func (c *Controller) GetSourceCode(ctx context.Context, request api.GetSourceCodeRequestObject) (api.GetSourceCodeResponseObject, error) {
	return api.GetSourceCode200ApplicationgzipResponse{}, nil
}
