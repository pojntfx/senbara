package po

import "embed"

//go:embed *
var FS embed.FS
