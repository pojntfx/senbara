# Senbara

Project convention reference for creating maintainable Go applications.

[![Weblate translation status](https://hosted.weblate.org/widget/senbara/svg-badge.svg)](https://hosted.weblate.org/engage/senbara/)

## Overview

🚧 This project is a work-in-progress! Instructions will be added as soon as it is usable. 🚧

This project was formerly known as Donna, and was a personal relationship management tool ("personal CRM"). It was named after [Donna Paulsen](https://suits.fandom.com/wiki/Donna_Paulsen), Harvey's assistant from the series "Suits".

## Contributing

To translate Senbara, you can use [Weblate](https://hosted.weblate.org/engage/senbara/). This is the current translation status:

[![Weblate translation status graphs](https://hosted.weblate.org/widget/senbara/multi-auto.svg)](https://hosted.weblate.org/engage/senbara/)

## License

Senbara (c) 2025 Felicitas Pojtinger and contributors

SPDX-License-Identifier: AGPL-3.0
