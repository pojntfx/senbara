package api

//go:generate go tool github.com/oapi-codegen/oapi-codegen/v2/cmd/oapi-codegen@latest --config=../openapi/openapi-codegen.yaml ../openapi/openapi.yaml
